﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsoleApplication1;
namespace niming
{
    public partial class Form1 : Form


    {



        P p;
        P p1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            p = new P();
            string file = Application.StartupPath;
            string datafile = file +"\\my.ini";
          //  MessageBox.Show(file);
            p.Ini(datafile);
            p1 = new P();
            p1.Ini(file +"\\myping.ini");
            List<string> lSec = p.ReadSections();
             int dd=1;

            int sc = lSec.Count;
            for (int i = 0; i < lSec.Count; i++)
            {

                List<string> lKeys = p.ReadKeys(lSec[sc-i-1]);
                int t = lKeys.Count;
                for (int k = 0; k < t; k++)
                {

                    this.listView1.Items.Add(dd+++"|"+lKeys[t-1-k]);

                }



            }
             
                //label3.Text = DateTime.Now.ToString();
          

        }

        
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("对不起，您还没有用户名,请输入一个用户名，谢谢");
            }

            else
            {

                label5.Text = "欢迎您，" + textBox1.Text;
                panel1.Visible = true;
              panel2.Visible = false;
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("对不起，您还没有用户名,请输入一个用户名，谢谢");
            }
            else
            {

                label5.Text = "欢迎您的到来，" + textBox1.Text;
                listView1.Visible = true;

            }

        }

        //private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    string s = listBox1.GetItemText(listBox1.SelectedItem);
        //    MessageBox.Show(s);
        //    int index = s.IndexOf("|");
        //    string s1 = s.Substring(index, s.Length - index);

        //    label6.Text = s1;

        //    List<string> lSec = p.ReadSections();

        //    for (int i = 0; i < lSec.Count; i++)
        //    {

        //        List<string> lKeys = p.ReadKeys(lSec[i]);

        //        for (int kk = 0; kk < lKeys.Count; kk++)
        //        {

        //            if (s1 == lKeys[kk])
        //            {
        //                String section = lSec[i];
        //              label7.Text = "楼主" + "|" + section + "|" + DateTime.Now.ToString();
        //                string sv = p.ReadValue(section, s1);

        //             richTextBox2.Text = sv + "\n\n";


        //                panel1.Visible = false;
        //                panel2.Visible = true;
        //                List<string> lps = p1.ReadSections();

        //                for (int ii = 0; ii < lps.Count; ii++)
        //                {
        //                    if (s1 == lps[ii])
        //                    {

        //                        List<string> lpk = p1.ReadKeys(lps[ii]);

        //                        for (int k = 0; k < lpk.Count; k++)
        //                        {

        //                            string pingl = p1.ReadValue(s1, lpk[k]);

        //                         richTextBox2.Text += lpk[k] + ":" + pingl + "\n";
        //                        }

        //                    }

        //                }


        //            }
        //        }


        //    }
        //}

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
         panel2.Visible = false;
         panel1.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text;
            string title = textBox2.Text;
            string content = richTextBox1.Text;
            if (title == "" || content == "")
            {
                MessageBox.Show("标题或内容不能为空");
                return;
            }
            p.Write(userName, title, content);
            
            MessageBox.Show("发表成功");
            textBox2.Text="";
             richTextBox1.Text="";
            listView1.Items.Add(title);
            listView1.Visible = true;
            panel1.Visible = false;
            listView1.Visible = true;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
             
            if (this.listView1.SelectedItems.Count > 0) { 
                string s = listView1.SelectedItems[0].Text;
                //MessageBox.Show(s);
            int index = s.IndexOf("|");
            string s1 = s.Substring(index+1, s.Length - index-1);

            label6.Text = s1;

            List<string> lSec = p.ReadSections();

                for (int i = 0; i < lSec.Count; i++)
                {

                    List<string> lKeys = p.ReadKeys(lSec[i]);

                    for (int kk = 0; kk < lKeys.Count; kk++)
                    {

                        if (s1 == lKeys[kk])
                        {
                            string section = lSec[i];
                          //  MessageBox.Show(section);
                           label9.Text = "楼主" + "|" + section ;
                            string sv = p.ReadValue(section, s1);

                            richTextBox2.Text = sv + "\n";


                            panel1.Visible = false;
                            panel2.Visible = true;
                             
                            List<string> lps = p1.ReadSections();

                            for (int ii = 0; ii < lps.Count; ii++)
                            {
                                if (s1 == lps[ii])
                                {

                                    List<string> lpk = p1.ReadKeys(lps[ii]);

                                    for (int k = 0; k < lpk.Count; k++)
                                    {

                                        string pingl = p1.ReadValue(s1, lpk[k]);
                                        string[] str = s.Split('|');
                                       // string s2 = s.Substring(index1 + 1, s.Length - index1 - 1);

                                        richTextBox2.Text += str[1] + ":" + pingl + "\n";
                                    }

                                }

                            }


                            return;
                        }
                    }

                }
            }
        }
        int i = 0;
        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("对不起，您还没有用户名,请输入一个用户名，谢谢");
                return;
            }
            if (richTextBox3.Text == "")
            {
                MessageBox.Show("对不起，评论内容不能为空，谢谢");
                return;
            }
            string time = System.DateTime.Now.ToString();
            richTextBox2.Text += "\n\n" + textBox1.Text + ":" + richTextBox3.Text + "\n" + time;



            p1.Write(label6.Text,time+"|"+textBox1.Text,richTextBox3.Text+"----"+time);
             MessageBox.Show("评论成功!");
            richTextBox3.Text="";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listView1.Visible = true;
            panel2.Visible = false;
            panel1.Visible = false;
            
        }

        private void listView1_Resize(object sender, EventArgs e)
        {
             
        }
    }
    }
